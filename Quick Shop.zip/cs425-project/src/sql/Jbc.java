package sql;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jbc {
		
		public Connection connection = get_connection(); // the connection is being called so that it can be used
			
			
		
		public Connection get_connection(){ // This method returns the connection to the database created
			
			Connection conn = null;
			
			try { //the connection is being created using the java database connector
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/new_schema","root","Bukkake*16");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
				System.out.print(e.toString());
				
			}
			
			return conn;
		}
		
		public void writeData(String query){
			// this is the insert query to write the data 
			try {
				
				PreparedStatement preparedStmt = connection.prepareStatement(query);
				preparedStmt.execute(); //the query is executed using the PreparedStatement class
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
			public ResultSet readData(String query) throws SQLException {
				//initiates connection 
				PreparedStatement ps=null;
				ResultSet rs = null;
            	    
            	    ps=connection.prepareStatement(query);
            	    rs=ps.executeQuery();
            	    
            	        
            	    
            	
				
				return rs;
			}
		
}
