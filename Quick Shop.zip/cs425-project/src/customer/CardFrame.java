package customer;

import javax.swing.JFrame;

public class CardFrame extends JFrame{

	public CardFrame() {
		// TODO Auto-generated constructor stub
	}

}
