package staff;

public class Product {

	public Product() {
		// TODO Auto-generated constructor stub
	}

}
